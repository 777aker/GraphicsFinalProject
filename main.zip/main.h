#ifndef MAIN_H
#define MAIN_H

#include "glututility.h"
#include "displayfunc.h"

#endif