#ifndef AUDIO_H
#define AUDIO_H

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <stdio.h>
#include <string>

#endif // !AUDIO_H
